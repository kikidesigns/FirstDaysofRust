// Import Input and Output Modules
use std::io;

// First Function To Run
fn main() {
    //Print An Intro Message
    println!("Welcome to the Nostr Chatbot! You can ask about NIPs and Event Kinds.");
    println!("Enter 'NIP-XX' to get information about a NIP, or 'Kind XX' to get information about an Event Kind (replace 'XX' with the NIP number or Event Kind number).");
//Start a Loop
    loop {
        //Create a Changeable Variable by Input
        let mut input = String::new();
        // Read The User Input
        io::stdin().read_line(&mut input).expect("Failed to read line");
        // Remove the Whitespaces
        let input = input.trim();
// Check if The User Input Starts with "nip-".
        if input.to_lowercase().starts_with("nip-") {
            // If Yes, Get The NIP Number by Removing "nip-" prefix.
            let nip_number = &input[4..];
            // Parse The NIP Number as an Unsigned 32-bit Integer.
            match nip_number.parse::<u32>() {
               // If parsing is successful, call the function to get NIP information.
                Ok(nip) => get_nip_info(nip),
                // If parsing fails, print an error message.
                Err(_) => println!("Invalid input. Please enter a valid NIP number (e.g., NIP-01) or Event Kind number (e.g., Kind 0)."),
            }
            // Check if the user input starts with "kind ".
        } else if input.to_lowercase().starts_with("kind ") {
            // If yes, extract the Event Kind number by removing "kind " prefix.
            let kind_number = &input[5..];
            // Parse the Event Kind number as an unsigned 32-bit integer.
            match kind_number.parse::<u32>() {
               // If parsing is successful, call the function to get Event Kind information.
                Ok(kind) => get_event_kind_info(kind),
                // If parsing fails, print an error message.
                Err(_) => println!("Invalid input. Please enter a valid NIP number (e.g., NIP-01) or Event Kind number (e.g., Kind 0)."),
            }
        } 
        // If the user input doesn't match any of the expected formats, print an error message.
        else {
            println!("Invalid input. Please enter a valid NIP number (e.g., NIP-01) or Event Kind number (e.g., Kind 0).");
        }
    }
}


// Function to get information about a specific NIP based on its number.
fn get_nip_info(nip_number: u32) {
   // Match the NIP number to corresponding NIPs and print their descriptions.
   match nip_number {
    // NIP-XX: Description
        
        1 => println!("NIP-01: Basic protocol flow description"),
        2 => println!("NIP-02: Contact List and Petnames"),
        3 => println!("NIP-03: OpenTimestamps Attestations for Events"),
        4 => println!("NIP-04: Encrypted Direct Message"),
        5 => println!("NIP-05: Mapping Nostr keys to DNS-based internet identifiers"),
        6 => println!("NIP-06: Basic key derivation from mnemonic seed phrase"),
        7 => println!("NIP-07: window.nostr capability for web browsers"),
        8 => println!("NIP-08: Handling Mentions --- unrecommended: deprecated in favor of NIP-27"),
        9 => println!("NIP-09: Event Deletion"),
        10 => println!("NIP-10: Conventions for clients' use of e and p tags in text events"),
        11 => println!("NIP-11: Relay Information Document"),
        12 => println!("NIP-12: Generic Tag Queries"),
        13 => println!("NIP-13: Proof of Work"),
        14 => println!("NIP-14: Subject tag in text events"),
        15 => println!("NIP-15: Nostr Marketplace (for resilient marketplaces)"),
        16 => println!("NIP-16: Event Treatment"),
        18 => println!("NIP-18: Reposts"),
        19 => println!("NIP-19: bech32-encoded entities"),
        20 => println!("NIP-20: Command Results"),
        21 => println!("NIP-21: nostr: URI scheme"),
        22 => println!("NIP-22: Event created_at Limits"),
        23 => println!("NIP-23: Long-form Content"),
        25 => println!("NIP-25: Reactions"),
        26 => println!("NIP-26: Delegated Event Signing"),
        27 => println!("NIP-27: Text Note References"),
        28 => println!("NIP-28: Public Chat"),
        30 => println!("NIP-30: Custom Emoji"),
        31 => println!("NIP-31: Dealing with Unknown Events"),
        32 => println!("NIP-32: Labeling"),
        33 => println!("NIP-33: Parameterized Replaceable Events"),
        36 => println!("NIP-36: Sensitive Content"),
        39 => println!("NIP-39: External Identities in Profiles"),
        40 => println!("NIP-40: Expiration Timestamp"),
        42 => println!("NIP-42: Authentication of clients to relays"),
        45 => println!("NIP-45: Counting results"),
        46 => println!("NIP-46: Nostr Connect"),
        47 => println!("NIP-47: Wallet Connect"),
        50 => println!("NIP-50: Keywords filter"),
        51 => println!("NIP-51: Lists"),
        53 => println!("NIP-53: Live Activities"),
        56 => println!("NIP-56: Reporting"),
        57 => println!("NIP-57: Lightning Zaps"),
        58 => println!("NIP-58: Badges"),
        65 => println!("NIP-65: Relay List Metadata"),
        78 => println!("NIP-78: Application-specific data"),
        89 => println!("NIP-89: Recommended Application Handlers"),
        94 => println!("NIP-94: File Metadata"),
        98 => println!("NIP-98: HTTP Auth"),
        99 => println!("NIP-99: Classified Listings"),
        _ => println!("NIP not found. Please enter a valid NIP number (e.g., NIP-01)."),
    }
}
// Function to get information about a specific Event Kind based on its number.

fn get_event_kind_info(kind_number: u32) {
    
    // Match the Event Kind number to corresponding kinds and print their descriptions.
    match kind_number {
        0 => println!("Kind 0: Metadata. This event kind represents metadata in Nostr."),
        1 => println!("Kind 1: Short Text Note. This event kind represents short text notes in Nostr."),
        2 => println!("Kind 2: Recommend Relay. This event kind represents recommending a relay in Nostr."),
        3 => println!("Kind 3: Contacts. This event kind represents contacts in Nostr."),
        4 => println!("Kind 4: Encrypted Direct Messages. This event kind represents encrypted direct messages in Nostr."),
        5 => println!("Kind 5: Event Deletion. This event kind represents event deletion in Nostr."),
        6 => println!("Kind 6: Repost. This event kind represents reposting an event in Nostr."),
        7 => println!("Kind 7: Reaction. This event kind represents reactions to events in Nostr."),
        8 => println!("Kind 8: Badge Award. This event kind represents badge awards in Nostr."),
        16 => println!("Kind 16: Generic Repost. This event kind represents generic reposts in Nostr."),
        40 => println!("Kind 40: Channel Creation. This event kind represents the creation of a channel in Nostr."),
        41 => println!("Kind 41: Channel Metadata. This event kind represents metadata for a channel in Nostr."),
        42 => println!("Kind 42: Channel Message. This event kind represents a message in a channel in Nostr."),
        43 => println!("Kind 43: Channel Hide Message. This event kind represents hiding a message in a channel in Nostr."),
        44 => println!("Kind 44: Channel Mute User. This event kind represents muting a user in a channel in Nostr."),
        1063 => println!("Kind 1063: File Metadata. This event kind represents file metadata in Nostr."),
        1311 => println!("Kind 1311: Live Chat Message. This event kind represents live chat messages in Nostr."),
        1984 => println!("Kind 1984: Reporting. This event kind represents reporting an event in Nostr."),
        1985 => println!("Kind 1985: Label. This event kind represents labels in Nostr."),
        9734 => println!("Kind 9734: Zap Request. This event kind represents zap requests in Nostr."),
        9735 => println!("Kind 9735: Zap. This event kind represents zaps in Nostr."),
        10000 => println!("Kind 10000: Mute List. This event kind represents mute lists in Nostr."),
        10001 => println!("Kind 10001: Pin List. This event kind represents pin lists in Nostr."),
        10002 => println!("Kind 10002: Relay List Metadata. This event kind represents relay list metadata in Nostr."),
        13194 => println!("Kind 13194: Wallet Info. This event kind represents wallet information in Nostr."),
        22242 => println!("Kind 22242: Client Authentication. This event kind represents client authentication in Nostr."),
        23194 => println!("Kind 23194: Wallet Request. This event kind represents wallet requests in Nostr."),
        23195 => println!("Kind 23195: Wallet Response. This event kind represents wallet responses in Nostr."),
        24133 => println!("Kind 24133: Nostr Connect. This event kind represents Nostr Connect in Nostr."),
        27235 => println!("Kind 27235: HTTP Auth. This event kind represents HTTP authentication in Nostr."),
        30000 => println!("Kind 30000: Categorized People List. This event kind represents categorized people lists in Nostr."),
        30001 => println!("Kind 30001: Categorized Bookmark List. This event kind represents categorized bookmark lists in Nostr."),
        30008 => println!("Kind 30008: Profile Badges. This event kind represents profile badges in Nostr."),
        30009 => println!("Kind 30009: Badge Definition. This event kind represents badge definitions in Nostr."),
        30017 => println!("Kind 30017: Create or update a stall. This event kind represents creating or updating a stall in Nostr."),
        30018 => println!("Kind 30018: Create or update a product. This event kind represents creating or updating a product in Nostr."),
        30023 => println!("Kind 30023: Long-form Content. This event kind represents long-form content in Nostr."),
        30024 => println!("Kind 30024: Draft Long-form Content. This event kind represents draft long-form content in Nostr."),
        30078 => println!("Kind 30078: Application-specific Data. This event kind represents application-specific data in Nostr."),
        30311 => println!("Kind 30311: Live Event. This event kind represents live events in Nostr."),
        30402 => println!("Kind 30402: Classified Listing. This event kind represents classified listings in Nostr."),
        30403 => println!("Kind 30403: Draft Classified Listing. This event kind represents draft classified listings in Nostr."),
        31989 => println!("Kind 31989: Handler recommendation. This event kind represents handler recommendations in Nostr."),
        31990 => println!("Kind 31990: Handler information. This event kind represents handler information in Nostr."),
        _ => println!("Kind not found. Please enter a valid NIP number (e.g., NIP-01) or Event Kind number (e.g., Kind 0)."),
    }
}
